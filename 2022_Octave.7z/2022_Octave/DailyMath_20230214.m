#{
mathopolis
Which graph illustrates the inequality -2x + 5y < 10?
#}

x = [10 -10 -10 10]; % Generate data for x vertices
y = [10 10 -10 -10]; % Generate data for y vertices
A = B = C = D = 1;
z = 1/C*(A*x + B*y + D); % Solve for z vertices data
patch(x, y, z);
legend("patch");
hold on;

x = y = linspace(-10, 10, 20);
[xx, yy] = meshgrid(x, y);
z = xx.*-2 + yy.*5;
mesh(x, y, z);

