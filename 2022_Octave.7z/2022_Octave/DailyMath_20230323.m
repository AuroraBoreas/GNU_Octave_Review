#{
f(x, y) = sin(x^2) - cos(y^2);
#}

x = y = linspace(-10, 10, 10);
[xx, yy] = meshgrid(x, y);
z = sin(xx.^3) - cos(yy.^2);
subplot(1,3,1), meshz(x, y, z);
subplot(1,3,2), mesh(x, y, z);
subplot(1,3,3), surface(x, y, z);
