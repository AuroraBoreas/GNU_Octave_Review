#{
the cylinder
#}
[x, y, z] = cylinder(10:2:20,40);
surface(x, y, z);
title("a cone");

