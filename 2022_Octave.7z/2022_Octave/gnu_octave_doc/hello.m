#! octave-interpreter-name -qf
# a sample Octave program
printf ("Hello, world!\n");
