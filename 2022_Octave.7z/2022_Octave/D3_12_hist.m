#{
statistics::hist3
#}

# pkg load statistics;

x = linspace(1,1,16)
y = linspace(1,1,16)
X = [x, y];
hist3(X);
